from django.apps import AppConfig


class LabConfig(AppConfig):
    name = 'lab'
