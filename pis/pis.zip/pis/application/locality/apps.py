from django.apps import AppConfig


class LocalityConfig(AppConfig):
    name = 'locality'
