from django.contrib import admin
from .models import NoticeBoard
# Register your models here.


admin.site.register(NoticeBoard)