from django.apps import AppConfig


class NoticebordConfig(AppConfig):
    name = 'noticebord'
