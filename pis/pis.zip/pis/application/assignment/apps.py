from django.apps import AppConfig


class AssignmentConfig(AppConfig):
    name = 'assignment'
