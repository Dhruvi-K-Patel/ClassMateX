from django.apps import AppConfig


class EbookConfig(AppConfig):
    name = 'ebook'
