from django.apps import AppConfig


class FeesConfig(AppConfig):
    name = 'fees'
